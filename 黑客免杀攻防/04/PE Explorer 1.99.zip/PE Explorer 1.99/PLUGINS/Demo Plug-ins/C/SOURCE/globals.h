// ---------------------------------------------------------------------------
// Product identifier string defines.

#define SZPLUGINNAME    "PE Explorer Demo Plugin in C\0"
#define SZDESCRIPTION   "PE Explorer Demo Plugin - C Language Version\0"
#define SZVERSION       "Version 1.0\0"
#define SZCOMPANYNAME   "Developer X\0"
#define SZCOPYRIGHTINFO "\251 Developer X, 2001\0"
#define SZEXENAME       "pexplgc.dll\0"

// ---------------------------------------------------------------------------



